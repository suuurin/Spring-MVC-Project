package com.board.mapper;

import java.util.List;

import org.springframework.ui.Model;

import com.board.domain.BoardVO;

public interface BoardMapper {
	
		//접근제어자, 리턴타입, 파라미터
		List<BoardVO> getList();
			
		int write(BoardVO board);
			
		BoardVO get(long bno);
			
		int delete(long bno);
			
		int modify(BoardVO board);

}
