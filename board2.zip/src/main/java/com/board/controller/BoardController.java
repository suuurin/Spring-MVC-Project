package com.board.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.board.domain.BoardVO;
import com.board.service.BoardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/board/*")
@Log4j
@RequiredArgsConstructor
public class BoardController {

	private final BoardService service;

	@GetMapping("list")
	public String getList(Model model) {
		model.addAttribute("list",service.getList());
		return"/board/list";
	}
	
	@PostMapping("write")
	public String write(BoardVO board){
		int write = service.write(board);
		return "redirect:/board/list";
	}
	
	@GetMapping("get")
	public String get(Long bno, Model model) {

		BoardVO board = service.get(bno);
		model.addAttribute("board", board);
		return"/board/view";
	}
	
	@GetMapping("modify")
	public String modify(Long bno, Model model) {
		BoardVO board = service.get(bno);
		model.addAttribute("board", board);
		return"/board/modify";
	}
	
	
	@RequestMapping(value="delete", method = RequestMethod.GET)
	public String delete(Long bno) {
		
		int count = service.delete(bno);
		
		return "redirect:/board/list";
	}
	


}
