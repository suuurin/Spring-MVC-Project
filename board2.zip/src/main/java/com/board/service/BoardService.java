package com.board.service;

import java.util.List;

import com.board.domain.BoardVO;

public interface BoardService {

	//list
	public List<BoardVO> getList();
	
	public BoardVO get(Long bno);
	
	public int write(BoardVO board);

	public int modify(BoardVO board);
	
	public int delete(Long bno);
	
}
